/* John Macdonald, October 18, 2022
 * 
 * This program determines probability of two different objects
 */


package project;

import java.util.ArrayList;
import java.util.Scanner;

public class ProbabilityTest {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		int[] n = new int[2];// used to store both numbers that are rolled or drawn
		int[] g = new int[2];// used to store user inputs
		
		for (int t = 0; t < 1;) {
		
		int newUserIn = 0;// user input
		int newUser = 0;// this is passed to most methods
		int totalDice = 0;// this equals the max of both dice
		int totalRoll = 0;// this equals the max of dice rolled
		int iterate = 0;// this is used for comparing two cards
		double times = 0;// this counts the number of times a number can be rolled on two dice 
		double totalPoss = 0.0;// this was used to calculate the total possibility of two dice
		double percentage = 0.0;// this was used to calculate the percentage (times / totalDice)
		
		ArrayList<Object> list = new ArrayList<>();// This stored Obj and Obj2, which are Probability and Probability2 respectively
		
		//intro
		System.out.print("What 2 probable objects would you like to compare?");

		for (int i = 0; i < 1; i++) {
			
		//choose an object to compare
		System.out.println("\nEnter one of these numbers to compare \n1 : d2,  2 : d4,  3 : d6,"
				+ "  4 : d8,\n5 : d10, 6 : d12, 7 : d20, 8 : 52 Card deck");
		
		//Saving input and storing values
		newUserIn = input.nextInt();
		newUser = newUserIn;
		g[0] = newUser;
		n[1] = 21;
		
		if (g[0] == 8) {
			iterate = 1;
		}
		
		//terminate if applicable
		if (newUser < 1 || newUser > 8) {
			System.out.print("Please choose a number on the list. Try again");
			System.exit(0);
		}
		
		//Create first object
			Probability Probability = new Probability();
			Probability.getDieNumber(
					Probability.setDice(
						Probability.setUserInput(
							Probability.getUserInput(newUser))));
			Probability.getMax(Probability.setUserInput(Probability.getUserInput(newUser)));
			Probability.getCardType();
			Probability.getCardSuit();
				list.add(Probability);
				n[0] = Probability.roll;
				
			

//Second object to compare
		System.out.println("\nEnter the second number to compare \n1 : d2,  2 : d4,  3 : d6,"
				+ "  4 : d8,\n5 : d10, 6 : d12, 7 : d20, 8 : 52 Card deck");
			
		//Saving input and storing values
			newUserIn = input.nextInt();
			newUser = newUserIn;
			g[1] = newUser;
			
		//termination if applicable
		if (newUser < 1 || newUser > 8) {
			System.out.print("Please choose a number on the list. Try again");
			System.exit(0);
		}
		
		
	//Create second object
		Probability Probability2 = new Probability();
		Probability2.getDieNumber(
				Probability2.setDice(
					Probability2.setUserInput(
						Probability2.getUserInput(newUser))));
			
			Probability2.getMax(Probability2.setUserInput(Probability2.getUserInput(newUser)));
			Probability2.getIterate(iterate);
			list.add(Probability2);
			n[1] = Probability2.roll;
			
		//redo randomizer if the card from the second object equals the card from the first object
			if (newUser == 8 && n[0] == n[1] && Probability2.cardType == Probability.cardType) {
				Probability2.getDieNumber(
					Probability2.setDice(
						Probability2.setUserInput(
							Probability2.getUserInput(newUser))));
				
				Probability.getMax(Probability.setUserInput(Probability.getUserInput(newUser)));
				Probability2.getIterate(iterate);
				Probability2.getCardType();
				Probability2.getCardSuit();
					n[1] = Probability2.roll;
				}//else if end
			
		}//for loop end
	
	//Storing objects into the array
		Probability Obj = (Probability)list.get(0);
		Probability Obj2 = (Probability)list.get(1);

		

		/* This code was used for testing purposes
		 *  
		System.out.println(Obj2.iterative);

		System.out.println("\nThese are user inputs " + g[0] + " " + g[1]);
		System.out.println("These are number outcomes " + n[0] + " " + n[1]);
		
		if(g[0] == 8 || g[1] == 8) {
		System.out.println("These are the card types " + Obj.cardType + " " + Obj2.cardType);
		}
		*/
		
	//compare display code
		System.out.println("\nHere are your results");
		
		//dice comparing
		for(int r = 0; r < 2; r++) {
			if(0 < g[r] && g[r] < 8) {
				if (r == 0) {
				newUser = g[r];
				System.out.println("You rolled a d" + (Obj.dieChosen.length) + " and got a " + (Obj.roll));
				}//if end

				else {
					newUser = g[r];
					System.out.println("You rolled a d" + (Obj2.dieChosen.length) + " and got a " + (Obj2.roll) + "\n");
					}//else end
			}//if end
			
		//card comparing
			else {
				if (r == 0) {
					newUser = g[r];
					System.out.println("You drew a " + Obj.royals(n[r]) + " of " + Obj.getCardSuit());
				}
				else {
					newUser = g[r];
					System.out.println("You drew a " + Obj2.royals(n[r]) + " of " + Obj2.getCardSuit() + "\n");
				}
			}//else end
			
		}//for loop end
		
		//System.out.println("This is the max " + Obj.max  + " " + Obj2.max); this was used for testing purposes
		
	//running important method before code percentage calculations
		Obj2.getProbability();
		
	//comparing two dice
		if(Obj.max < 50 && Obj2.max < 50) {
			totalDice = (int)Obj.max + (int)Obj2.max;
			totalPoss = (int)Obj.max * (int)Obj2.max;
			totalRoll = Obj.roll + Obj2.roll;
			for(int o = 0; o < Obj.dieChosen.length; o++) {
				for (int p = 0; p < Obj2.dieChosen.length; p++) {
					if(totalRoll == Obj.dieChosen[o] + Obj2.dieChosen[p]) {
						times++;
					}
				}//Obj2 counting for loop end
			}//Obj counting for loop end
			percentage = times / totalDice;
			System.out.println("The max that can be rolled is " + (int)(Obj.max + Obj2.max));
			System.out.printf("The probability of the first object is %2.3f \n", (Obj.getProbability()));
			System.out.printf("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
			System.out.println("The total of " + totalRoll + " can be rolled " + (int)times + " times out of " + (int)totalPoss + " possible rolls");
			System.out.printf((int)times + " divided by " + (int)totalPoss + " equals a %2.1f percent chance \n", ((times / totalPoss) * 100));
		}//if end
		
	//comparing two cards
		else if(Obj.max == 52 && Obj2.max == 51) {
			System.out.println("The max number of cards that can be drawn is " + (int)(Obj.max));
			System.out.printf("The probability of the first object is %2.4f \n", (Obj.getProbability()));
			System.out.printf("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
			System.out.printf("The total chance of drawing these cards is a %2.1f percent chance \n", (((Obj.getProbability() + Obj2.getProbability()) * 100)));
		}
	
	//comparing a card and a die
		else if(Obj.max == 52 && Obj2.max < 50){
			System.out.println("The max number of cards that can be drawn is " + (int)(Obj.max));
			System.out.println("The max that can be rolled is " + (int)(Obj2.max));
			System.out.printf("The probability of the first object is %2.4f \n", (Obj.getProbability()));
			System.out.printf("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
			System.out.printf("The total chance of drawing a card and rolling a die is %2.1f percent chance \n", (((Obj.getProbability() + Obj2.getProbability()) * 100)));
		}
		
	//comparing a die and a card
		else {
			System.out.println("The max that can be rolled is " + (int)(Obj.max));
			System.out.println("The max number of cards that can be drawn is " + (int)(Obj2.max));
			System.out.printf("The probability of the first object is %2.3f \n", (Obj.getProbability()));
			System.out.printf("The probability of the second object is %2.4f \n", (Obj2.getProbability()));
			System.out.printf("The total chance of rolling a die and drawing a card is %2.1f percent chance \n", (((Obj.getProbability() + Obj2.getProbability()) * 100)));
		}
		
	//final, display and input code
		System.out.println("\n\nWould you like to compare two more objects?");
		
		System.out.println("Enter 0 for yes and any other number for no");
		t = input.nextInt();
		System.out.println();

		}//terminating for loop end
		
		System.out.println("Thank you for trying out my probability calculator.");
		

	}//Method main end

}//Class ProbabilityTest end
