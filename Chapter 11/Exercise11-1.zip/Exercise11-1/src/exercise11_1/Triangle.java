//John Macdonald, Oct. 4, 2022
//Implementation for Exercise 11-1

package exercise11_1;

import java.util.Date;

public class Triangle extends GeometricObject {
	

	//Data Fields

	double side1 = 1.0;

	double side2 = 1.0;

	double side3 = 1.0;
	
	String colors = "";
	
	boolean filled;
	
	private long date = System.currentTimeMillis();
	
	
	
	//Constructors

	Triangle(){}

	Triangle(double side1, double side2, double side3){
		
	}


	//Methods
	
	String getSetColors(String color) {
		String colors = color;
		return colors;
	}
	
	boolean getSetFill(boolean fill) {
		boolean filled = fill;
		return filled;
	}
	
	Date getDateCreated() {
		java.util.Date date = new java.util.Date();
		return date;
	}
	
	double getSetSide1(double newSide1){
		side1 = newSide1;
		return side1;
	}

	double getSetSide2(double newSide2){
		side2 = newSide2;
		return side2;		
	}

	double getSetSide3(double newSide3){
		side3 = newSide3;
		return side3;		
	}

	double getArea(double side1, double side2, double side3){
		double s = (side1 + side2 + side3) / 2;
		double area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
		return area;
	} //returns area

	double getPerimeter(double side1, double side2, double side3){
		double perimeter = side1 + side2 + side3;
		return perimeter;
	} //returns perimeter of triangle

	public String toString(){
		return "Triangle: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3;
	} //returns triangle string description
	
	
}//class Triangle end