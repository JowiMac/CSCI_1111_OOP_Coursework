//John Macdonald, Oct. 4, 2022
//Test Exercise 11-1


/* Write a test program that prompts the user to
 * enter three sides of the triangle, a color, and
 * a Boolean value to indicate whether the triangle
 * is filled. The program should create a Triangle
 * object with these sides and set the color and
 * filled properties using the input. The program
 * should display the area, perimeter, color, date
 * created, and true or false to indicate whether
 * it is filled or not. 
 * */

package exercise11_1;

import java.util.Scanner;

public class testTriangle {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		Triangle Triangle = new Triangle();
		
		System.out.print("Enter 3 sides of a triangle separated by a space: ");
		
		double newSide1 = input.nextDouble();
		Triangle.getSetSide1(newSide1);
		
		double newSide2 = input.nextDouble();
		Triangle.getSetSide2(newSide2);
		
		double newSide3 = input.nextDouble();
		Triangle.getSetSide3(newSide3);
		
		System.out.print("What is the Triangle's color: ");
		String color = input.next();
		
		System.out.print("Is the Triangle filled in? true for yes and false for no: ");
		boolean fill = input.nextBoolean();
		
		System.out.println("\n\n" + Triangle.toString());
		System.out.println("The area is " + Triangle.getArea(newSide1, newSide2, newSide3));
		System.out.println("The perimeter is " + Triangle.getPerimeter(newSide1, newSide2, newSide3));
		System.out.println("The color is " + Triangle.getSetColors(color));
		System.out.println("Date created on " + Triangle.getDateCreated());
		System.out.println("Is it filled in? " + Triangle.getSetFill(fill));
	
	}// main method end
}// class testTriangle end
