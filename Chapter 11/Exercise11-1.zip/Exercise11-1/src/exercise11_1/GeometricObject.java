package exercise11_1;

public class GeometricObject {

}// class GeometricObject end
