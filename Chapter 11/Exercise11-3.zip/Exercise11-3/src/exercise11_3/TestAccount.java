package exercise11_3;

/* John Macdonald
 * Sept. 23, 2022
 * 
 * Implementation
 * for Exercise 9-7 
 */

import java.util.Scanner;
import java.util.Date;

public class TestAccount {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		Account Account = new Account();
		
		//Identification
		System.out.print("Create an Id number: ");
		int newId  = input.nextInt();
		Account.setId(newId);
		System.out.println("Your ID number is: " + Account.getId());
		System.out.println("This was created on " + Account.getDateCreated() + "\n");
		
		//Balance
		System.out.print("What is the starting balance? ");
		double newBalance = input.nextDouble();
		Account.setBalance(newBalance);
		System.out.printf("Your balance is $%6.2f \n\n", Account.getBalance());
		
		//Interest Rate
		System.out.print("What is the interest rate? ");
		double newAnnualInterestRate = input.nextDouble();
		Account.setAnnualInterestRate(newAnnualInterestRate);
		System.out.print("The interest rate is " + Account.getAnnualInterestRate() + "\n\n");
		
		//Withdraw
		System.out.print("Would you like to withdraw from Checking:1 or Savings:0 ? ");
		int o = input.nextInt();
		if (o == 1) {
			System.out.print("You have selected Checking");
			Checking Checking = new Checking();
			
			System.out.print("\nHow much would you like to withdraw? ");
			double withdrawing = input.nextDouble();
			newBalance = Account.withdraw((Account.getBalance()), withdrawing);
			Account.setBalance(newBalance);
			
			if(Account.getBalance() < -100) {
				newBalance = -100;
				System.out.print(Checking.toString());
				Account.setBalance(newBalance);
			}
			
			System.out.printf("\nYour balance is $%6.2f \n\n", Account.getBalance());
		
		}
		else if (o == 0) {
			System.out.print("You have selected Savings");
			Savings Savings = new Savings();
			
			System.out.print("\nHow much would you like to withdraw? ");
			double withdrawing = input.nextDouble();
			newBalance = Account.withdraw((Account.getBalance()), withdrawing);
			Account.setBalance(newBalance);
			
			if(Account.getBalance() < 0) {
				newBalance = 0;
				System.out.print(Savings.toString());
				Account.setBalance(newBalance);
			}
			
			System.out.printf("\nYour balance is $%6.2f \n\n", Account.getBalance());
		}
		else {
			System.out.print("Please select 1 for Checking and 0 for Savings, try again");
			System.exit(0);
		}//if statements end
		
		
		//Deposit
		System.out.print("How much would you like to deposit? ");
		double depositing = input.nextDouble();
		newBalance = Account.deposit((Account.getBalance()), depositing);
		Account.setBalance(newBalance);
		System.out.printf("Your balance is %6.2f \n\n", Account.getBalance());
		
		System.exit(0);		
		
	}//method main end
}//class TestAccount end
