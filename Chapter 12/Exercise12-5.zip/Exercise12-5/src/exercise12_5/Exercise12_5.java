/* John Macdonald
 * October 10, 2022
 * 
 * This code creates a text file and sorts the random
 * numbers sent to it
 * */

package exercise12_5;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Arrays;

public class Exercise12_5 {
	public static void main(String[] args) {
		
		int[] f = new int[100];
		
		int[] t = new int[100];

		for (int i = 0; i < 100; i++) {
			f[i] = (int)(Math.random() * 200);
		}
		
		
		
		File file = new File("Exercise12_15.txt");
		
		if (file.exists()) {
			System.out.print("This file already exists");
			System.exit(0);
		}
		
				System.out.print("The absolute path of the new file is " + file.getAbsolutePath() + "\n");
		
		try {
				
		PrintWriter output = new PrintWriter(file);
				
		for(int j = 0; j < 100; j++) {
		output.print(f[j] + " ");
		}
		
		output.close();
		
				
		
		Scanner input = new Scanner(file);
		
		int o = 0;
		
		while (input.hasNext()) {
			int number = input.nextInt();
			
			t[o] = number;
			
			o++;
		}//while end
		
		Arrays.sort(t);
		
		for(int y = 0; y < 100; y++) {
			System.out.print(t[y] + " ");
			
			if (y == 55) {
				System.out.println();
			}//if end
		}//for end
		
		input.close();
		
		}//try end
		
		
		catch(java.io.FileNotFoundException ex) {
			System.out.print("File not found");
		}//catch end
		
		
		
	}
}
