/* John Macdonald
 * October 10, 2022
 * 
 * This code creates an array and tests try catch methods
 * */

package exercise12_3;

import java.util.Scanner;

public class Exercise12_3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		int[] f = new int[100];
		
		for (int i = 0; i < 100; i++) {
			f[i] = (int)(Math.random() * 100);
		}
		
		System.out.print("Enter a number from 1 - 100 to select an array number: ");
		
		int a = input.nextInt() - 1;
		
		if(a < 0 || a > 99) {
			System.out.print("Out of bounds");
		}
		else {
		System.out.print("Your number from the array is " + f[a]);
		}
		
	}
}
