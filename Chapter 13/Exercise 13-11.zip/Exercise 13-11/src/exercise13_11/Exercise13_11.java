/* John Macdonald, Oct. 13, 2022
 * This code creates a triangle
 * from user input.
 * */

//This is the test file

package exercise13_11;

import java.util.Scanner;

public class Exercise13_11 {
	public static void main(String[] args) throws CloneNotSupportedException {
		Scanner input = new Scanner(System.in);
		
		double newSide = 1.0;
		
		GeometricObject[] octagonArray = new GeometricObject[2];
		
		System.out.print("Enter a side, to equal all sides, of an octagon ");
		newSide = input.nextDouble();
		
		double newSide1 = newSide;
		double newSide2 = newSide;
		double newSide3 = newSide;
		double newSide4 = newSide;
		double newSide5 = newSide;
		double newSide6 = newSide;
		double newSide7 = newSide;
		double newSide8 = newSide;
		
		Octagon Octagon1 = new Octagon(newSide1, newSide2, newSide3, newSide4,
				newSide5, newSide6, newSide7, newSide8);
		octagonArray[0] = Octagon1;
		
		System.out.println("\nThis is the Area " + Octagon1.getArea());
		System.out.println("This is the Perimeter " + Octagon1.getPerimeter());
		
		System.out.println();
		
		Octagon Octagon2 = (Octagon)Octagon1.clone();
		
		System.out.println("Octagon has been cloned");
		
		octagonArray[1] = Octagon2;
		
		if(Octagon2.compareTo(Octagon1) == 0) {
			System.out.print("They are equal");
		}
		else {
			System.out.print("They are not equal");
		}
		
		
	}//Method main end
}//Class Exercise13-11 end
