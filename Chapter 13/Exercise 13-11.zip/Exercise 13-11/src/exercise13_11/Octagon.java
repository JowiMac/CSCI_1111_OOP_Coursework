/* John Macdonald, Oct. 13, 2022
 * This code creates a triangle
 * from user input.
 * */

package exercise13_11;

import java.lang.Math;

public class Octagon extends GeometricObject implements Cloneable, Comparable<Octagon>{
	
	//Data Fields
	double side1 = 1.0;
	double side2 = 1.0;
	double side3 = 1.0;
	double side4 = 1.0;
	double side5 = 1.0;
	double side6 = 1.0;
	double side7 = 1.0;
	double side8 = 1.0;
	
		
	//Constructors
	Octagon(){}
	
	Octagon(double newSide1, double newSide2, double newSide3,
			double newSide4, double newSide5, double newSide6,
			double newSide7, double newSide8){
		
		side1 = newSide1;
		side2 = newSide2;
		side3 = newSide3;
		side4 = newSide4;
		side5 = newSide5;
		side6 = newSide6;
		side7 = newSide7;
		side8 = newSide8;
		
		}//Octagon Constructor end

		 

		//Methods

		//  get methods
		double getSide1(){
			return side1;
		}
		double getSide2(){
			return side2;
		}
		double getSide3(){
			return side3;
		}
		double getSide4(){
			return side4;
		}
		double getSide5(){
			return side5;
		}
		double getSide6(){
			return side6;
		}
		double getSide7(){
			return side7;
		}
		double getSide8(){
			return side8;
		}
		
		
		@Override
		public Object clone() throws CloneNotSupportedException{
			return super.clone();
		}
		
		@Override
		public int compareTo(Octagon Octagon1) {
			
			if(Octagon1.side1 == this.side1)
				return 0;
			else if (Octagon1.side1 < this.side1)
				return 1;
			else 
				return -1;
		}
		
		
		@Override
		public double getArea() {
			double octArea = (2 + (4 /(Math.sqrt(2)) )) * side1 * side2;
			return octArea;
		}

		@Override
		public double getPerimeter() {
			double octPer = 2 * (side1 + side2 + side3 + side4 + side5 + side6 + side7 + side8);
			return octPer;
		}


}//class Octagon end
