/* John Macdonald, Oct. 13, 2022
 * This code creates a triangle
 * from user input.
 * */

package exercise13_11;

abstract class GeometricObject {

	public abstract double getArea();
	
	public abstract double getPerimeter();
	
}//GeometricObject end