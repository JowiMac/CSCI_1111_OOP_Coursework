/* John Macdonald, Oct. 12, 2022
 * This code creates a triangle
 * from user input.
 * */

package exercise13_1;

public class Triangle extends GeometricObject{
	
	//Data Fields
	double side1 = 1.0;
	double side2 = 1.0;
	double side3 = 1.0;
	String color = "";
	boolean fill = false;
	
	//Constructors
	Triangle(){}
	
	Triangle(double newSide1, double newSide2, double newSide3, String newColor, boolean newFill){
		side1 = newSide1;
		side2 = newSide2;
		side3 = newSide3;
		color = newColor;
		fill = newFill;

		}//Triangle Constructor end

		 

		//Methods

		double getSide1(){
		return side1;
		}
		
		double getSide2(){
		return side2;
		}
		
		double getSide3(){
		return side3;
		}
		
		String getColor() {
		return color;
		}
		
		boolean getFill() {
		return fill;
		}
		
		
		@Override
		public double getArea() {
			double triArea = side1 * side2 * side3;
			return triArea;
		}

		@Override
		public double getPerimeter() {
			double triPer = 2 * (side1 + side2 + side3);
			return triPer;
		}


}//class Triangle end
