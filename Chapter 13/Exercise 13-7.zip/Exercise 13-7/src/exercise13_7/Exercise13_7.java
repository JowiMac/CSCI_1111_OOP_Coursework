/* John Macdonald, Oct. 12, 2022
 * This code creates a triangle
 * from user input.
 * */

//This is the test file

package exercise13_7;

import java.util.Scanner;

public class Exercise13_7 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		double newSide1 = 1.0;
		double newSide2 = 1.0;
		double newSide3 = 1.0;
		String newColor = "";
		boolean newFill = false;
		
		GeometricObject[] triangleArray = new GeometricObject[5];
		for (int j = 0; j < triangleArray.length; j++) {
		
		System.out.print("Enter 3 sides of a triangle ");
		newSide1 = input.nextDouble();
		newSide2 = input.nextDouble();
		newSide3 = input.nextDouble();
		
		System.out.print("Enter a color string ");
		newColor = input.next();
		
		System.out.print("Enter true or false for the triangle to be filled ");
		newFill = input.nextBoolean();
		
		Triangle Triangle = new Triangle(newSide1, newSide2, newSide3, newColor, newFill);
		triangleArray[j] = Triangle;
		
		//System.out.println("\nThis is side1 " + Triangle.getSide1());
		//System.out.println("This is side2 " + Triangle.getSide2());
		//System.out.println("This is side3 " + Triangle.getSide3());
		System.out.println("\nThis is the color " + Triangle.getColor());
		System.out.println("This is the fill " + Triangle.getFill());
		
		System.out.println("\nThis is the Area " + Triangle.getArea());
		System.out.println("This is the Perimeter " + Triangle.getPerimeter());
		Triangle.howToColor();
		System.out.println();
		}//for loop end
		
	}
}
