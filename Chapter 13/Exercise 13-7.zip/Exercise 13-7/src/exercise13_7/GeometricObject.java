/* John Macdonald, Oct. 12, 2022
 * This code creates a triangle
 * from user input.
 * */

package exercise13_7;

abstract class GeometricObject {

	public abstract double getArea();
	
	public abstract double getPerimeter();
	
}//GeometricObject end