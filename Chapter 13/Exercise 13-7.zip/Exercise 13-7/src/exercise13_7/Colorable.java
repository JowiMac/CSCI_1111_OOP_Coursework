package exercise13_7;

public interface Colorable {
	void howToColor();
}//Colorable interface end
